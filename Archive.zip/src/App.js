import { useState, useEffect } from "react";
import { PostList } from "./PostList";
import { PostForm } from "./PostForm";

const initialPosts = [
  {
    id: 1,
    username: "a",
    content: "Learning React hooks!",
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    likes: 5,
  },
  {
    id: 2,
    username: "b",
    content: "This dashboard is coming along nicely!",
    timestamp: new Date(),
    likes: 10,
  },
];

export default function App() {
  const [posts, setPosts] = useState(initialPosts);
  const [filteredPosts, setFilteredPosts] = useState(initialPosts);
  const [filter, setFilter] = useState({ username: "", sortBy: "newest" });

  const handleLike = (postId) => {
    setPosts((prev) =>
      prev.map((post) =>
        post.id === postId ? { ...post, likes: post.likes + 1 } : post
      )
    );
  };

  // Filter the posts based on the current filter state
  const onSearchInputChange = (event) => {
    const username = event.target.value;
    setFilter({ ...filter, username });
  };

  const onSortChange = (event) => {
    const sortBy = event.target.value;
    setFilter({ ...filter, sortBy });
  };

  useEffect(() => {
    // const username = filter.username;
    // const sortBy = filter.sortBy;

    const { username, sortBy } = filter;

    const postsCopy = [...posts];

    console.log("username", username);
    // console.log("postsCopy", postsCopy);
    // if (username.trim() !== "") {
    // console.log('username not empty');

    postsCopy.filter((post) =>
      post.username.toLowerCase().includes(username.toLowerCase())
    );
    // }

    console.log("postsCopy", postsCopy);

    setFilteredPosts(postsCopy);
  }, [filter, posts]);

  return (
    <div className="App">
      <h1>Social Dashboard</h1>

      {/* <div>username value in state: {filter.username}</div> */}
      <input
        type="text"
        placeholder="filter posts by username"
        onChange={onSearchInputChange}
        value={filter.username}
      />

      <div>
        {/* <div>Sortby value in state: {filter.sortBy}</div> */}
        <select value={filter.sortBy} onChange={onSortChange}>
          <option value="newest">newest</option>
          <option value="oldest">oldest</option>
        </select>
      </div>

      <PostList posts={filteredPosts} onLike={handleLike} />

      {/* <PostForm /> */}
    </div>
  );
}
