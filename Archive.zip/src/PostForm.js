import { useState } from "react";

export function PostForm({ onAddPost }) {
  const [content, setContent] = useState("");
  const maxLength = 280;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (e.target.value === "" || e.target.value.length > 280) {
      alert("Please enter text");
    } else {
      setContent(e.target.value);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        maxLength={maxLength}
        placeholder="What's happening?"
        rows={3}
      />
      <div>
        <span>
          {content.length}/{maxLength}
        </span>
        <button type="submit" disabled={!content.trim()}>
          Post
        </button>
      </div>
    </form>
  );
}
