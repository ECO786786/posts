export const PostList = ({ posts, onLike }) => {
  console.log(posts);

  return (
    <div>
      {posts.map((post) => (
        <div key={post.id} className="post">
          <h3>{post.username}</h3>
          <p>{post.content}</p>
          <small>{new Date(post.timestamp).toLocaleString()}</small>
          <div>
            <button onClick={() => onLike(post.id)}>Like ({post.likes})</button>
          </div>
        </div>
      ))}
    </div>
  );
};
